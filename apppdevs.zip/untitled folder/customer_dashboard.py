from tkinter import *
from customer_transaction import customer_transaction
from add_transaction import open_add_transaction_modal
from notification import notification
from profile import profile


def load_dashboard(parent):
    list_section(parent)
    plus_button(parent)

pages = {
    "Dashboard": load_dashboard,
    "Transaction": lambda parent: customer_transaction(parent, lambda: load("Dashboard")),
    "Add Transaction": open_add_transaction_modal,
    "Notification": notification,
    "Profile": profile
}



def list_section(parent):
    section = Frame(parent, bg="#f5f5f5")
    section.pack(padx=20, pady=20, fill="both", expand=True)

    item = Frame(section,
                 bg="white",
                 highlightbackground="gray",
                 highlightthickness=1,
                 cursor="hand2")
    
    item.pack(fill="x", pady=5)

    label = Label(item,
                  text="app dev.pdf",
                  bg="white",
                  fg="black",
                  font=("Arial", 12),
                  anchor="w")
    
    label.pack(side="left", padx=10, pady=10)

    pending_label = Label(item, text="Pending", bg="white", fg="black", font=("Arial", 12,))
    pending_label.pack(side="right", padx=10, pady=10)

    label.bind("<Button-1>", lambda e: load("Transaction"))

def plus_button(parent):
    plus_button = Button(parent,
                         text="+",
                         font=("Arial", 20, "bold"),
                         bg="#1E3A8A", fg="white",
                         width=3, height=1, bd=0,
                         relief="flat", command=lambda: load("Add Transaction"))
    
    plus_button.place(relx=0.95, rely=0.85, anchor="center")

def topbar(parent):
    topbar = Frame(parent, bg="white", height=50)
    topbar.pack(side="top", fill="x")
    topbar.pack_propagate(False)

    logo_label = Label(topbar, text="Hera Printing",
                       bg="white", fg="black",
                       font=("Arial", 14, "bold"))
    
    logo_label.pack(side="left", padx=20, pady=10)
    logo_label.bind("<Button-1>", lambda e: load("Dashboard"))

    notif_icon = Label(topbar, text="Notification", bg="white", fg="black", font=("Arial", 12))
    notif_icon.pack(side="right", padx=10, pady=10)
    notif_icon.bind("<Button-1>", lambda e: load("Notification"))

    profile_icon = Label(topbar, text="Profile", bg="white", fg="black", font=("Arial", 12))
    profile_icon.pack(side="right", padx=10, pady=10)
    profile_icon.bind("<Button-1>", lambda e: load("Profile"))
    #####################==================================================================############
def load(page):
    for widget in content.winfo_children():
        widget.destroy()
    pages.get(page, lambda x: None)(content)
root = Tk()
root.title("Hera Printing Online")
root.geometry("900x500")
root.configure(bg="#f5f5f5")

topbar(root)

content = Frame(root, bg="#f5f5f5")
content.pack(expand=True, fill="both")

load("Dashboard")

root.mainloop()

