from tkinter import *
from db_connection import db_connection

def dashboard(parent):
    for widget in parent.winfo_children():
        widget.destroy()

    conn = db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM customers")
    total_customers = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM transactions")
    total_transactions = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM transactions WHERE status = 'Picked Up'")
    picked_up = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM transactions WHERE status = 'Not Picked Up'")
    not_picked_up = cursor.fetchone()[0]

    conn.close()

    Label(parent, text="Dashboard", font=("Arial", 18)).pack(pady=10, anchor='e', fill='x', padx=20)

    summary_frame = Frame(parent)
    summary_frame.pack(padx=20, pady=10, fill="x")

    def summary_box(master, title, value, bg_color):
        box = Frame(master, bg=bg_color, padx=15, pady=15, bd=1, relief="solid")
        box.pack(side=LEFT, padx=10, pady=5, fill="both", expand=True)
        Label(box, text=title, font=("Arial", 12), bg=bg_color, fg="white").pack(anchor="w")
        Label(box, text=str(value), font=("Arial", 18, "bold"), bg=bg_color, fg="white").pack(anchor="w")

    summary_box(summary_frame, "Total Customers", total_customers, "#2196f3")
    summary_box(summary_frame, "Total Transactions", total_transactions, "#9c27b0")
    summary_box(summary_frame, "Picked Up", picked_up, "#009688")
    summary_box(summary_frame, "Not Picked Up", not_picked_up, "#ff9800")
