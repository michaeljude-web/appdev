from tkinter import *
from tkinter import messagebox
from db_connection import db_connection
import subprocess

def login(username, password, root):
    mydb = db_connection()
    if mydb:
        cursor = mydb.cursor()
        query = "SELECT * FROM employee WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        if result:
            root.destroy()
            subprocess.Popen(["python", "employee_main.py"])
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")
        cursor.close()
        mydb.close()


def login_screen():
    root = Tk()
    root.title("Alog's Daily Record System")
    root.geometry("900x500")
    root.configure(bg="#f0f0f0")

    container = Frame(root, bg="white",
                      highlightbackground="black",
                      highlightthickness=2)
    container.place(relx=0.5, rely=0.5, anchor="center", width=350, height=450)

    Label(container, text="Alog's Daily Laundry",
          font=("Arial", 16, "bold"), bg="white", fg="black").pack(pady=(30, 10))

    Label(container, text="Employee Login",
          font=("Arial", 16), bg="white", fg="gray").pack(pady=(0, 40))

    Label(container, text="Username:",
          font=("Arial", 10), bg="white", fg="black").pack(anchor="w", padx=30)
    
    username_entry = Entry(container, font=("Arial", 10), bd=1,
                        fg="black", relief="solid", bg="#f9f9f9")
    username_entry.pack(pady=5, ipady=6, fill="x", padx=30)

    Label(container, text="Password:",
          font=("Arial", 10), bg="white", fg="black").pack(anchor="w", padx=30)
    
    password_entry = Entry(container, font=("Arial", 10), bd=1,
                           relief="solid", bg="#f9f9f9", fg="black", show="*")
    password_entry.pack(pady=5, ipady=6, fill="x", padx=30)

    login_btn = Button(container, text="Login",
                       bg="black", fg="white", font=("Arial", 10, "bold"),
                       relief="flat", height=2,
                       command=lambda: login(username_entry.get(), password_entry.get(), root))
    login_btn.pack(fill="x", padx=30, pady=(20, 30))

    root.mainloop()

login_screen()
