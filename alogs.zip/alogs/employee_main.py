from tkinter import *
import subprocess
from employee_dashboard import dashboard
from employee_laundry import laundry
from employee_customer import customer

pages = {
    "Dashboard": dashboard,
    "Laundry": laundry,
    "Customer": customer
}

def load(page):
    for widget in content.winfo_children():
        widget.destroy()
    pages.get(page, lambda x: None)(content)

def logout_user():
    root.destroy()
    subprocess.Popen(["python", "employee_login.py"])

def create_sidebar(parent, on_select):
    sidebar = Frame(parent, bg="#2c3e50", width=200)
    sidebar.pack(side="left", fill="y")

    Label(sidebar, text="Employee Panel", font=("Arial", 14, "bold"), bg="#2c3e50", fg="white").pack(pady=(20, 10))

    menu_sidebar = [
        ("Dashboard", "Dashboard"),
        ("Laundry", "Laundry"),
        ("Customer", "Customer")
    ]

    for text, label in menu_sidebar:
        item = Button(sidebar,
                      text=text,
                      font=("Arial", 10),
                      bg="#34495e",
                      fg="white",
                      relief="flat")
        item.config(command=lambda l=label: on_select(l))
        item.pack(fill="x", pady=10, padx=10)

    logout = Button(sidebar,
                    text="Logout",
                    font=("Arial", 10),
                    bg="#34495e",
                    fg="white",
                    relief="flat",
                    command=logout_user)
    logout.pack(fill="x", pady=(0, 20), padx=10)


root = Tk()
root.title("Employee Dashboard")
root.geometry("900x500")
root.configure(bg="#f0f0f0")

create_sidebar(root, load)

content = Frame(root, bg="#ecf0f1")
content.pack(expand=True, fill="both")

load("Dashboard")

root.mainloop()
