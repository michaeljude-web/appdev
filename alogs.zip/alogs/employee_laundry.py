from tkinter import *
from tkinter import ttk, messagebox
from db_connection import db_connection
import datetime

def laundry(parent):
    for widget in parent.winfo_children():
        widget.destroy()

    Label(parent, text="Laundry", font=("Arial", 18)).pack(pady=10, anchor='e', fill='x', padx=20)
    Button(parent, text="➕ Add Laundry", bg="blue", fg="white", command=lambda: open_modal(parent)).pack(pady=10)

    list_frame = Frame(parent)
    list_frame.pack(fill=BOTH, expand=True, padx=20)

    cols = ("Date", "Customer", "Baskets", "Detergent", "Total", "Status", "Action")
    tree = ttk.Treeview(list_frame, columns=cols, show='headings')
    for col in cols:
        tree.heading(col, text=col)
        tree.column(col, anchor=CENTER, width=120)
    tree.pack(fill=BOTH, expand=True)

    def load_data():
        for row in tree.get_children():
            tree.delete(row)
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("""
    SELECT t.id, DATE_FORMAT(t.date, '%Y-%m-%d'), c.fullname, 
           t.basket_count, t.detergent_powder_count, t.total_price, t.status
    FROM transactions t
    JOIN customers c ON t.customer_id = c.customer_id
    WHERE t.status = 'Not Picked Up'
""")

        for row in cursor.fetchall():
            tree.insert("", END, values=row[1:] + ("Mark as Picked Up",), tags=(str(row[0]),))
        conn.close()

    def on_tree_click(event):
        item = tree.identify_row(event.y)
        if item:
            trans_id = tree.item(item, 'tags')[0]
            selected = tree.item(item, 'values')
            if selected[-1] == "Mark as Picked Up":
                confirm = messagebox.askyesno("Confirm", "Mark this as Picked Up?")
                if confirm:
                    conn = db_connection()
                    cursor = conn.cursor()
                    today = datetime.date.today().isoformat()
                    cursor.execute("UPDATE transactions SET status='Picked Up', pickup_date=%s WHERE id=%s", (today, trans_id))
                    conn.commit()
                    conn.close()
                    load_data()

    tree.bind("<Double-1>", on_tree_click)
    load_data()

def open_modal(parent):
    modal = Toplevel(parent)
    modal.title("Add Laundry")
    modal.geometry("450x550")

    Label(modal, text="Customer Info", font=("Arial", 14)).pack(pady=5)
    form = Frame(modal)
    form.pack(pady=10)

    Label(form, text="Search Existing:").grid(row=0, column=0, sticky=E, pady=5)
    search_var = StringVar()
    search_entry = Entry(form, textvariable=search_var)
    search_entry.grid(row=0, column=1)

    customer_dropdown = ttk.Combobox(form, state="readonly")
    customer_dropdown.grid(row=1, column=1, pady=5)
    Label(form, text="Select Customer:").grid(row=1, column=0, sticky=E)

    fullname_entry = Entry(form)
    address_entry = Entry(form)
    contact_entry = Entry(form)

    Label(form, text="Full Name:").grid(row=2, column=0, sticky=E, pady=5)
    fullname_entry.grid(row=2, column=1)

    Label(form, text="Address:").grid(row=3, column=0, sticky=E, pady=5)
    address_entry.grid(row=3, column=1)

    Label(form, text="Contact:").grid(row=4, column=0, sticky=E, pady=5)
    contact_entry.grid(row=4, column=1)

#SA DISABLE
    def on_customer_select(event):
        if customer_dropdown.get():
            fullname_entry.config(state='disabled')
            address_entry.config(state='disabled')
            contact_entry.config(state='disabled')

    customer_dropdown.bind("<<ComboboxSelected>>", on_customer_select)

    def update_dropdown(*args):
        keyword = search_var.get()
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT customer_id, fullname FROM customers WHERE fullname LIKE %s", (f"%{keyword}%",))
        results = cursor.fetchall()
        customer_dropdown["values"] = [f"{row[0]} - {row[1]}" for row in results]
        conn.close()

    search_var.trace_add("write", update_dropdown)

    Label(modal, text="Laundry Info", font=("Arial", 14)).pack(pady=10)
    laundry_form = Frame(modal)
    laundry_form.pack()

    Label(laundry_form, text="Basket P60:").grid(row=0, column=0, sticky=E, pady=5)
    basket_entry = Entry(laundry_form)
    basket_entry.grid(row=0, column=1)

    Label(laundry_form, text="Detergent P20:").grid(row=1, column=0, sticky=E, pady=5)
    detergent_entry = Entry(laundry_form)
    detergent_entry.grid(row=1, column=1)

    total_label = Label(laundry_form, text="Total: ₱0.00", font=("Arial", 12, "bold"), fg="green")
    total_label.grid(row=2, column=0, columnspan=2, pady=10)

    def update_total(*args):
        try:
            basket = int(basket_entry.get()) if basket_entry.get() else 0
            detergent = int(detergent_entry.get()) if detergent_entry.get() else 0
            total = basket * 60 + detergent * 20
            total_label.config(text=f"Total: ₱{total:.2f}")
        except ValueError:
            total_label.config(text="Total: ₱0.00")

    basket_entry.bind("<KeyRelease>", update_total)
    detergent_entry.bind("<KeyRelease>", update_total)

    def submit_laundry():
        basket = basket_entry.get()
        detergent = detergent_entry.get()
        if not basket or not detergent:
            messagebox.showerror("Error", "Please enter basket and detergent counts.")
            return

        try:
            basket = int(basket)
            detergent = int(detergent)
            total = basket * 60 + detergent * 20
            today = datetime.date.today().isoformat()

            conn = db_connection()
            cursor = conn.cursor()

            if customer_dropdown.get():
                selected = customer_dropdown.get().split(" - ")[0]
                customer_id = int(selected)
            else:
                if not fullname_entry.get() or not address_entry.get() or not contact_entry.get():
                    messagebox.showerror("Error", "Please fill out full customer info.")
                    return
                cursor.execute("INSERT INTO customers (fullname, address, contact) VALUES (%s, %s, %s)",
                               (fullname_entry.get(), address_entry.get(), contact_entry.get()))
                customer_id = cursor.lastrowid

            cursor.execute("""
                INSERT INTO transactions (customer_id, basket_count, detergent_powder_count, total_price, date, status)
                VALUES (%s, %s, %s, %s, %s, 'Not Picked Up')
            """, (customer_id, basket, detergent, total, today))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Laundry transaction saved.")
            modal.destroy()
            laundry(parent)

        except Exception as e:
            messagebox.showerror("Error", str(e))

    Button(modal, text="Submit Laundry", command=submit_laundry, bg="green", fg="white").pack(pady=20)
