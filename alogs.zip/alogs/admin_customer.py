from tkinter import *
from tkinter import ttk
import mysql.connector
from db_connection import db_connection


def customer(parent):
    for widget in parent.winfo_children():
        widget.destroy()

    Label(parent, text="Customer List", font=("Arial", 16)).pack(pady=10, anchor='e', fill='x', padx=20)


    frame = Frame(parent)
    frame.pack(fill=BOTH, expand=True, padx=20, pady=10)

    columns = ("ID", "Full Name", "Address", "Contact")
    tree = ttk.Treeview(frame, columns=columns, show="headings")
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor=W, width=150)
    tree.pack(fill=BOTH, expand=True)

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT customer_id, fullname, address, contact FROM customers")
    for row in cursor.fetchall():
        tree.insert("", END, values=row)
    conn.close()

    def on_customer_select(event):
        selected = tree.focus()
        if not selected:
            return
        data = tree.item(selected)['values']
        customer_id = data[0]
        fullname = data[1]
        show_customer_transactions(parent, customer_id, fullname)

    tree.bind("<<TreeviewSelect>>", on_customer_select)

def show_customer_transactions(parent, customer_id, fullname):
    modal = Toplevel(parent)
    modal.title(f"{fullname}'s Transactions")
    modal.geometry("800x400")
    modal.transient(parent)

    Label(modal, text=f"Transactions of {fullname}", font=("Arial", 16)).pack(pady=10)

    trans_frame = Frame(modal)
    trans_frame.pack(fill=BOTH, expand=True, padx=10, pady=10)

    columns = ("Date", "Pickup Date", "Baskets", "Detergents", "Total", "Status")
    trans_tree = ttk.Treeview(trans_frame, columns=columns, show="headings")
    for col in columns:
        trans_tree.heading(col, text=col)
        trans_tree.column(col, anchor=CENTER, width=100)
    trans_tree.pack(fill=BOTH, expand=True)

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    SELECT 
        DATE_FORMAT(date, '%Y-%m-%d'),
        DATE_FORMAT(pickup_date, '%Y-%m-%d'),
        basket_count,
        detergent_powder_count,
        total_price,
        status
    FROM transactions
    WHERE customer_id = %s AND status = 'Picked up'
    ORDER BY date DESC
""", (customer_id,))

    transactions = cursor.fetchall()
    for row in transactions:
        trans_tree.insert("", END, values=row)
    conn.close()

    modal.after(100, lambda: modal.grab_set())
