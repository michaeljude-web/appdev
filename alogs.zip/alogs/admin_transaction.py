from tkinter import *
from tkinter import ttk
from db_connection import db_connection

def transaction(parent):
    for widget in parent.winfo_children():
        widget.destroy()

    Label(parent, text="Transaction History", font=("Arial", 18)).pack(pady=10, anchor='e', fill='x', padx=20)

    list_frame = Frame(parent)
    list_frame.pack(fill=BOTH, expand=True, padx=20, pady=10)

    columns = ("Date", "Pickup Date", "Customer", "Baskets", "Detergents", "Total Price", "Status")
    tree = ttk.Treeview(list_frame, columns=columns, show="headings")
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor=CENTER, width=120)
    tree.pack(fill=BOTH, expand=True)

    def load_transaction_data():
        tree.delete(*tree.get_children())
        conn = db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT 
                DATE_FORMAT(t.date, '%Y-%m-%d') AS formatted_date,
                DATE_FORMAT(t.pickup_date, '%Y-%m-%d') AS pickup_date,
                c.fullname,
                t.basket_count,
                t.detergent_powder_count,
                t.total_price,
                t.status
            FROM transactions t
            JOIN customers c ON t.customer_id = c.customer_id
            WHERE t.status = 'Picked up'
            ORDER BY t.date DESC
        """)
        rows = cursor.fetchall()
        for row in rows:
            tree.insert("", END, values=row)

        conn.close()

    load_transaction_data()
