from tkinter import *
from tkinter import ttk, messagebox
from db_connection import db_connection
from datetime import datetime

def employee(parent):
    for widget in parent.winfo_children():
        widget.destroy()

    top_frame = Frame(parent, bg="#f5f5f5")
    top_frame.pack(side="top", fill="x")
    
    Label(top_frame, text="Employee List", font=("Arial", 16)).pack(fill='x', padx=10, pady=10)


    add_button = Button(top_frame, text="Add Employee", command=lambda: add_employee(parent))
    add_button.pack(side="left", padx=10, pady=10)

    middle_frame = Frame(parent, bg="#f5f5f5")
    middle_frame.pack(side="top", fill="both", expand=True)

    employee_list = ttk.Treeview(middle_frame)
    employee_list['columns'] = ('employee_id', 'fullname', 'age', 'address', 'contact', 'date_created')

    employee_list.column("#0", width=0, stretch=NO)
    employee_list.column("employee_id", width=0, stretch=NO)
    employee_list.column("fullname", anchor=W, width=200)
    employee_list.column("age", anchor=W, width=50)
    employee_list.column("address", anchor=W, width=200)
    employee_list.column("contact", anchor=W, width=150)
    employee_list.column("date_created", anchor=W, width=150)

    employee_list.heading("#0", text='', anchor=W)
    employee_list.heading('fullname', text='Fullname', anchor=W)
    employee_list.heading('age', text='Age', anchor=W)
    employee_list.heading('address', text='Address', anchor=W)
    employee_list.heading('contact', text='Contact', anchor=W)
    employee_list.heading('date_created', text='Date Added', anchor=W)

    employee_list.pack(fill="both", expand=True, padx=10, pady=10)

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT employee_id, fullname, age, address, contact, date_created FROM employee")
    employees = cursor.fetchall()

    for employee in employees:
        employee_list.insert('', 'end', values=(employee[0], employee[1], employee[2], employee[3], employee[4], employee[5]))

    conn.close()

    selected_employee_id = StringVar()

    def on_tree_select(event):
        selected = employee_list.focus()
        values = employee_list.item(selected, 'values')
        if values:
            selected_employee_id.set(values[0])
        else:
            selected_employee_id.set('')

    employee_list.bind("<<TreeviewSelect>>", on_tree_select)

    action_frame = Frame(parent, bg="#f5f5f5")
    action_frame.pack(pady=(0, 10))
#-------------------------------------------------------------------
    edit_btn = Button(top_frame, text="Edit", command=lambda: edit_employee(parent, selected_employee_id.get()))
    edit_btn.pack(side="left", padx=10)

    delete_btn = Button(top_frame, text="Delete", command=lambda: confirm_delete(parent, selected_employee_id.get()))
    delete_btn.pack(side="left", padx=10)
#---------------------------------------------------------------------------
def add_employee(parent):
    add_window = Toplevel(parent)
    add_window.title("Add Employee")

    Label(add_window, text="Fullname").grid(row=0, column=0, padx=10, pady=10)
    fullname_entry = Entry(add_window)
    fullname_entry.grid(row=0, column=1, padx=10, pady=10)

    Label(add_window, text="Age").grid(row=1, column=0, padx=10, pady=10)
    age_entry = Entry(add_window)
    age_entry.grid(row=1, column=1, padx=10, pady=10)

    Label(add_window, text="Address").grid(row=2, column=0, padx=10, pady=10)
    address_entry = Entry(add_window)
    address_entry.grid(row=2, column=1, padx=10, pady=10)

    Label(add_window, text="Contact").grid(row=3, column=0, padx=10, pady=10)
    contact_entry = Entry(add_window)
    contact_entry.grid(row=3, column=1, padx=10, pady=10)

    Label(add_window, text="Username").grid(row=4, column=0, padx=10, pady=10)
    username_entry = Entry(add_window)
    username_entry.grid(row=4, column=1, padx=10, pady=10)

    Label(add_window, text="Password").grid(row=5, column=0, padx=10, pady=10)
    password_entry = Entry(add_window, show="*")
    password_entry.grid(row=5, column=1, padx=10, pady=10)

    def save_employee():
        try:
            age_val = int(age_entry.get())
        except ValueError:
            messagebox.showerror("Invalid input", "Age must be a number.")
            return
        if not fullname_entry.get().strip():
            messagebox.showerror("Input error", "Fullname is required.")
            return

        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO employee (fullname, age, address, contact, username, password, date_created) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       (fullname_entry.get(), age_val, address_entry.get(), contact_entry.get(), username_entry.get(), password_entry.get(), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()
        add_window.destroy()
        employee(parent)

    save_button = Button(add_window, text="Save", command=save_employee)
    save_button.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

def edit_employee(parent, employee_id):
    if not employee_id:
        messagebox.showwarning("No Selection", "Please select an employee to edit.")
        return

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM employee WHERE employee_id = %s", (employee_id,))
    employee_data = cursor.fetchone()
    conn.close()

    if not employee_data:
        messagebox.showerror("Error", "Employee data not found.")
        return

    edit_window = Toplevel(parent)
    edit_window.title("Edit Employee")

    Label(edit_window, text="Fullname").grid(row=0, column=0, padx=10, pady=10)
    fullname_entry = Entry(edit_window)
    fullname_entry.insert(0, employee_data[1])
    fullname_entry.grid(row=0, column=1, padx=10, pady=10)

    Label(edit_window, text="Age").grid(row=1, column=0, padx=10, pady=10)
    age_entry = Entry(edit_window)
    age_entry.insert(0, employee_data[2])
    age_entry.grid(row=1, column=1, padx=10, pady=10)

    Label(edit_window, text="Address").grid(row=2, column=0, padx=10, pady=10)
    address_entry = Entry(edit_window)
    address_entry.insert(0, employee_data[3])
    address_entry.grid(row=2, column=1, padx=10, pady=10)

    Label(edit_window, text="Contact").grid(row=3, column=0, padx=10, pady=10)
    contact_entry = Entry(edit_window)
    contact_entry.insert(0, employee_data[4])
    contact_entry.grid(row=3, column=1, padx=10, pady=10)

   # Label(edit_window, text="Username").grid(row=4, column=0, padx=10, pady=10)
   # username_entry = Entry(edit_window)
   # username_entry.insert(0, employee_data[5])
   # username_entry.grid(row=4, column=1, padx=10, pady=10)

  #  Label(edit_window, text="Password").grid(row=5, column=0, padx=10, pady=10)
   # password_entry = Entry(edit_window)
   # password_entry.insert(0, employee_data[6])
  #  password_entry.grid(row=5, column=1, padx=10, pady=10)

    def save_changes():
        try:
            age_val = int(age_entry.get())
        except ValueError:
            messagebox.showerror("Invalid input", "Age must be a number.")
            return
        if not fullname_entry.get().strip():
            messagebox.showerror("Input error", "Fullname is required.")
            return

        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE employee SET fullname = %s, age = %s, address = %s, contact = %s WHERE employee_id = %s",
                       (fullname_entry.get(), age_val, address_entry.get(), contact_entry.get(), employee_id))
        conn.commit()
        conn.close()
        edit_window.destroy()
        employee(parent)

    save_button = Button(edit_window, text="Save Changes", command=save_changes)
    save_button.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

def confirm_delete(parent, employee_id):
    if not employee_id:
        messagebox.showwarning("No Selection", "Please select an employee to delete.")
        return
    confirm = messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this employee?")
    if confirm:
        delete_employee(parent, employee_id)

def delete_employee(parent, employee_id):
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM employee WHERE employee_id = %s", (employee_id,))
    conn.commit()
    conn.close()
    employee(parent)
