from tkinter import *
from tkinter import messagebox
from db_connection import db_connection 
import subprocess

def open_login():
    subprocess.Popen(["python", "customer_login.py"])

def save_account(name, email, password, root):
    if not name or not email or not password:
        messagebox.showerror("Error", "Please fill in all fields")
        return

    try:
        mydb = db_connection()
        cursor = mydb.cursor()

        cursor.execute("SELECT * FROM customer WHERE email = %s", (email,))
        if cursor.fetchone():
            messagebox.showerror("Error", "Email already registered")
            return

        query = "INSERT INTO customer (full_name, email, password, status) VALUES (%s, %s, %s, %s)"
        cursor.execute(query, (name, email, password, 'Pending'))
        mydb.commit()

        messagebox.showinfo("Success", "Account created successfully! Please wait for admin approval.")
        root.destroy()
        open_login()

    except Exception as e:
        messagebox.showerror("Database Error", str(e))

    finally:
        if cursor:
            cursor.close()
        if mydb:
            mydb.close()

def create_account_screen():
    root = Tk()
    root.title("Hera Online Printing")
    root.geometry("900x500")
    root.configure(bg="white")

    container = Frame(root, bg="white",
                      highlightbackground="#1E3A8A", highlightthickness=2)
    container.place(relx=0.5, rely=0.5, anchor="center", width=320, height=460)

    Label(container,
          text="Hera Online Printing",
          font=("Arial", 14, "bold"), bg="white", fg="black").pack(pady=(20, 5))
    Label(container,
          text="Create Account ",
          font=("Arial", 18), bg="white",
          fg="black").pack(pady=(0, 60))

    Label(container,
          text="Full Name:",
          font=("Arial", 10),
          bg="white", fg="black").pack(anchor="w", padx=30)
    name_entry = Entry(container,
                       font=("Arial", 10), bd=1, fg="black",
                       relief="solid", bg="white")
    name_entry.pack(pady=5, ipady=6, fill="x", padx=30)

    Label(container,
          text="Email address:",
          font=("Arial", 10), bg="white",
          fg="black").pack(anchor="w", padx=30)
    email_entry = Entry(container,
                        font=("Arial", 10),
                        bd=1, fg="black", relief="solid", bg="white")
    email_entry.pack(pady=5, ipady=6, fill="x", padx=30)

    Label(container,
          text="Password:",
          font=("Arial", 10), bg="white",
          fg="black").pack(anchor="w", padx=30)
    password_entry = Entry(container,
                           font=("Arial", 10), bd=1, relief="solid", bg="white", show="*")
    password_entry.pack(pady=5, ipady=6, fill="x", padx=30)

    create_btn = Button(container,
                        text="Create Account",
                        bg="#1E3A8A",
                        fg="white",
                        font=("Arial", 10),
                        relief="flat",
                        height=2,
                        command=lambda: save_account(name_entry.get(), email_entry.get(), password_entry.get(), root))
    create_btn.pack(fill="x", padx=30, pady=(15, 10))

    login_label = Label(container,
                        text="Already have an account? Login here",
                        fg="#1E3A8A",
                        bg="white",
                        cursor="hand2",
                        font=("Arial", 9, "underline"))
    login_label.pack()
    login_label.bind("<Button-1>", lambda e: [root.destroy(), open_login()])

    root.mainloop()

create_account_screen()
