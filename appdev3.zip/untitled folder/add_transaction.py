from tkinter import *
from tkinter import ttk, filedialog, messagebox

def open_add_transaction_modal(master):
    def select_file():
        file = filedialog.askopenfilename(
            title="Select a file",
            filetypes=[("Word Files", "*.docx"), ("All Files", "*.*")]
        )
        if file:
            file_entry_var.set(file)

    def send_transaction():
        file_path = file_entry_var.get()
        size = size_var.get()
        copies = copies_entry.get()
        print_type_val = print_type.get()

        if not file_path:
            messagebox.showerror("Error", "Please select a file.")
            return
        if not copies.isdigit() or int(copies) <= 0:
            messagebox.showerror("Error", "Please enter a valid number of copies.")
            return

        # Save to DB logic here

        messagebox.showinfo("Success", "Transaction sent successfully!")
        modal.destroy()

    modal = Toplevel(master)
    modal.title("Add Transaction")
    modal.geometry("400x420")
    modal.configure(bg="white")
    modal.grab_set()
    modal.resizable(False, False)

    box = Frame(modal, bg="white", bd=1, relief="solid")
    box.pack(pady=20, padx=20, fill="x")

    Label(box, text="Select file", bg="white", fg="black", anchor="w").grid(row=0, column=0, sticky="w", padx=20, pady=(20,5), columnspan=2)

    file_entry_var = StringVar()
    file_entry = Entry(box, textvariable=file_entry_var, bg="white", fg="black", state="readonly")
    file_entry.grid(row=1, column=0, padx=(20,5), pady=5, sticky="ew")
    Button(box, text="Browse", command=select_file).grid(row=1, column=1, padx=(0,20), pady=5)

    box.columnconfigure(0, weight=1)

    Label(box, text="Select size", bg="white", fg="black", anchor="w").grid(row=2, column=0, sticky="w", padx=20, pady=(15,5), columnspan=2)

    size_var = StringVar(value="A4")
    size_combo = ttk.Combobox(box, textvariable=size_var, values=["A4", "SHORT", "LONG"], state="readonly")
    size_combo.grid(row=3, column=0, padx=20, pady=5, sticky="ew", columnspan=2)

    Label(box, text="Number of copies", bg="white", fg="black", anchor="w").grid(row=4, column=0, sticky="w", padx=20, pady=(15,5), columnspan=2)

    copies_entry = Entry(box, bg="white", fg="black")
    copies_entry.grid(row=5, column=0, padx=20, pady=5, sticky="ew", columnspan=2)

    Label(box, text="", bg="white").grid(row=6, column=0, pady=5)

    type_frame = Frame(box, bg="white")
    type_frame.grid(row=7, column=0, columnspan=2, pady=5)

    print_type = StringVar(value="B&W")
    Radiobutton(type_frame, text="B&W", variable=print_type, value="B&W", bg="white", fg="black").pack(side="left", padx=10)
    Radiobutton(type_frame, text="Colored", variable=print_type, value="Colored", bg="white", fg="black").pack(side="left", padx=10)

    send_btn = Button(box, text="Send", bg="#1E3A8A", fg="white", width=20, command=send_transaction)
    send_btn.grid(row=8, column=0, columnspan=2, pady=20)

    box.grid_columnconfigure(0, weight=1)
