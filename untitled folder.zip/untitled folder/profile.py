from tkinter import *

def profile(parent):
    for widget in parent.winfo_children():
        widget.destroy()



    Label(parent,
          text="Update Profile",
          font=("Arial", 12, "bold"),
          bg="#f5f5f5",
          fg="black").pack(fill="x", pady=10)





